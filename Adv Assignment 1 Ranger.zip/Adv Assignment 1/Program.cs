﻿using System;
using System.Collections;
using System.Linq;
using System.Linq.Expressions;

namespace Adv_Assignment_1
{
    
    class Program
    {
        
        static void Main(string[] args)
        {
            var mathExpressionVisitor = new MathExpressionVisitor();
            var testString = "15 7 1 1 + - / 3 * 2 1 1 + + -";
            Console.WriteLine($"Input: {testString}");
            stringVal val = new stringVal();
            if (val.validate(testString))
            {


                string[] stringParts = testString.Split(' ');
                foreach (string a in stringParts)
                {

                    mathExpressionVisitor.ElementHandler(a);
                }
                Console.WriteLine($"Top of the stack at the end of the element handler: {mathExpressionVisitor.numStack.Peek().ToString()}");
                Console.WriteLine($"Direct compile of the above expression from the stack: {Expression.Lambda((Expression)mathExpressionVisitor.numStack.Peek()).Compile().DynamicInvoke()}");
                var updatedMathExpression = mathExpressionVisitor.Visit((Expression)mathExpressionVisitor.numStack.Pop());

                Console.WriteLine($"Updated math expression after the tree visitor: {updatedMathExpression}");
                
                Console.WriteLine($"Compile for the expression modified by the visitor: {Expression.Lambda(updatedMathExpression).Compile().DynamicInvoke()}");
            }
            else
            {
                Console.WriteLine("Please use RPN.");
            }
            Console.ReadKey();

        }
    }

    public class stringVal
    {
        public stringVal()
        {

        }

        public bool validate(string userInput)
        {
            var query = from s in userInput.Split(' ')
                        where (int.TryParse(s,out int a)) ||
                        (s == "+") ||
                        (s == "-") ||
                        (s == "*") ||
                        (s == "/") ||
                        (s == "^")
                        select s;
            if (query.Count() == userInput.Split(' ').Count())
            {
                return true;
            }
            return false;
        }
    }
    

    public class MathExpressionVisitor : ExpressionVisitor
    {
        public Stack numStack = new Stack();
        public MathExpressionVisitor()
        {

        }

        public void ElementHandler(string element)
        {
            int value;
            ExpressionType tempType = new ExpressionType();
            if (int.TryParse(element, out value))
            {
                numStack.Push(Expression.Constant(value));
                return;
            }
            else if (element == "+")
            {
                tempType = ExpressionType.Add;
            }
            else if (element == "-")
            {
                tempType = ExpressionType.Subtract;
            }
            else if (element == "*")
            {
                tempType = ExpressionType.Multiply;
            }
            else if (element == "/")
            {
                tempType = ExpressionType.Divide;
            }
            else if (element == "^")
            {
                tempType = ExpressionType.Power;
            }
            var right = numStack.Pop();
            var left = numStack.Pop();

            var binaryExpression = Expression.MakeBinary(tempType, (Expression)left, (Expression)right);
            numStack.Push(binaryExpression);
            
        }
        public override Expression Visit(Expression node)
        {
            switch (node.NodeType)
            {
                case ExpressionType.Add:
                case ExpressionType.Subtract:
                case ExpressionType.Multiply:
                case ExpressionType.Divide:
                case ExpressionType.Power:
                    return this.VisitBinary((BinaryExpression)node);
                default:
                    
                    return base.Visit(node);
            }

        }

        protected override Expression VisitBinary(BinaryExpression node)
        {
            var right = this.Visit(node.Right);
            var left = this.Visit(node.Left);
            switch (node.NodeType)
            {
                
                case ExpressionType.Add:
                    return Expression.MakeBinary(ExpressionType.Add, left, right);
                case ExpressionType.Subtract: 
                    return Expression.MakeBinary(ExpressionType.Subtract, left, right);
                case ExpressionType.Multiply:
                    return Expression.MakeBinary(ExpressionType.Multiply, left, right);
                case ExpressionType.Divide:
                    return Expression.MakeBinary(ExpressionType.Divide, left, right);
                case ExpressionType.Power:
                    
                    return Expression.MakeBinary(ExpressionType.Power, left, right);
                default:
                    return base.VisitBinary(node);
            }

        }
        protected override Expression VisitConstant(ConstantExpression node)
        {
            return node;
        }

    }
}
